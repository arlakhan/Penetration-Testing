import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;

public class PenetrationTesting {

    public static void main(String[] args) {
        String txtFile = "Targets.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(txtFile))) {
            String ipAddress;
            while ((ipAddress = br.readLine()) != null) {
                System.out.println("Testing target IP: " + ipAddress);
                boolean reachable = isHostReachable(ipAddress, 5000);
                System.out.println("Target " + ipAddress + " is " + (reachable ? "reachable" : "not reachable"));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean isHostReachable(String ipAddress, int timeout) {
        try {
            InetAddress inet = InetAddress.getByName(ipAddress);
            return inet.isReachable(timeout);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
